import sklearn
from arftools import *
from utility import *
from CostFunc import * 
from image import *

from sklearn.model_selection import GridSearchCV

from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso

import numpy as np

# import sys
# np.set_printoptions(threshold=sys.maxsize)


######################################################################################################################################################################
'''paramètres'''
# #(7291,256)(7291,)
train = load_usps("USPS/USPS_train.txt")
# #(2007,256)(2007,)
test = load_usps("USPS/USPS_test.txt")

c1 = 1
c2 = 3
train = class_versus_class(train[0], train[1], c1,c2)
test = class_versus_class(test[0], test[1], c1,c2)

alpha=0.1

#######################################################################

pixels = open_in_hsv("rsc/sample.png")

######################################################################################
'''Question 1'''

def procedure(regression, train_data, test_data, alpha=0.1):
    reg = regression(alpha= alpha)
    reg.fit(train_data[0], train_data[1])
    #print(reg.score(test_data[0], test_data[1]))
    cost = mse_batch(test_data[0], test_data[1], reg.coef_) 
    print(cost)
    print( reg.coef_ )
    print( np.linalg.norm( reg.coef_) )
    print(reg.intercept_) 

    reg.coef_ = np.array(reg.coef_).reshape((16,16))
    plt.figure()
    plt.imshow(reg.coef_, interpolation="nearest")
    plt.colorbar()
    plt.show()

# print("\nLinear\n")
# procedure(LinearRegression, train, test)
# #coef distribué plutôt équitablement

# print("\nRidge\n")
# procedure(Ridge, train, test, alpha=0.1)
# #plus grande disparité entre les coef 
# #norme similaire au linéaire

# print("\nLasso\n")
# procedure(Lasso, train, test, alpha=0.1)
# #biais nul
# #présence de coef nuls
# #norme très inférieur aux autres 


# #Les coûts sont toujours très proches.

# TODO : tester en fonction de alpha

#########################################################################################################
'''Question 2'''

#functions
def find_weigth( patch_vec, dictionnaire_vecs):
    feature = patch_vec[0]
    classe = patch_vec[1]

    # train_X = dictionnaire_vecs[0]
    # train_Y = dictionnaire_vecs[1]

    # reg = Lasso()
    # reg.fit([], [])
    # reg.predict(feature)
    # weights = reg.coef_


    # return weights



############################
#function calls

#TODO extend range to [-1,1]

# patch = get_patch(pixels,1,70,300)
n_pixels = noise(pixels, 0.01)   #combine with delete rect()

patch_mat = find_patch(n_pixels, 4)
all_patches, mat_shape = vectorize_mat(patch_mat)
all_features, patch_shape = vectorize_list(all_patches)
all_classes = classify_liste( all_features )

noisy, clean = split_patches(patch_mat)
c_vecs = vectorize_part_mat(clean)
n_vecs = vectorize_part_mat(noisy)
print(n_vecs.shape, c_vecs.shape)

c_classes = classify_liste(c_vecs)
# print(c_classes)
n_classes = classify_liste(n_vecs)
# print(n_classes)

corrupt_index = find_corruption(all_features)

reg = Lasso(max_iter=10000 ,alpha= 0.005)
reg.fit( all_features, all_classes )
weights = reg.coef_
# print(reg.coef_, sum(reg.coef_))

done = False
it = 0
while not done:
    for i in range(len(all_classes)):
        patch = all_patches[i]
        vec = all_features[i]
        classe = all_classes[i]

        #le patch n'est pas corrompu, on ne fait rien
        if(i not in corrupt_index):
            continue

        # add noise level to noisy patch's y
        noise_level = noise_in_patch( patch )
        

        #on fout le patch bruité et les non-bruité ensemble, et on cherche la ligne la plus probable donc on approxime par rapport à ce patch
        trainX = np.append([vec], c_vecs, axis=0)
        trainY = np.append(classe, c_classes) 

        # print(trainY)

        reg.fit(trainX,trainY)
        p_weight = reg.coef_

        new_classe = vec.dot(p_weight) + noise_level
        # print(reg.coef_, sum(reg.coef_))
        # print(sum(reg.coef_))
        # print(reg.predict([vec]))

        #on change le vecteur en sommant les patch avec leur poids, sans le patch p
        new_vec = vec
        for j in range(len(vec)):
            if(vec[j] != -100):
                continue
            vec[j] = 0
            for v in range(len(c_vecs)):
                if( v == i ):
                    continue
                #ne modifier que les pixels corrompus
                new_vec[j] += c_vecs[v][j] * p_weight[j]
            # new_vec += clean_vec(all_features[j]).dot(weights)

        # new_vec = np.where(vec == -100, formule, vec)
        
        new_patch = patchify(new_vec, patch_shape)
        all_patches[i] = new_patch
        all_features[i] = new_vec
        all_classes[i] = new_classe

    new_pixels = reconstruct( all_patches, mat_shape )
    print(new_pixels)
    if( scan_patch(new_pixels) == False ):
        done = True


new_pixels = clean_format(new_pixels)
n_pixels = clean_format(n_pixels)

compare_pic( new_pixels, n_pixels, pixels)
# hsv_to_pic( new_pixels )
# hsv_to_pic( pixels )

#Q2
# augmenter alpha réduit le nombre de solution, on obtient plus fréquemment des vecteurs poids nuls 
# en baissant alpha on obtient plus facilement des vecteurs poids non-nuls, non seulement ça mais aussi plus de poids non-nuls en général.
# avec un alpha trop grand on n'obtient pas de solution, mais avec un alpha très petit, la solution n'est aussi pas très expressif




#Q3
# pixels = delete_rect(pixels, 50,100,150,150)