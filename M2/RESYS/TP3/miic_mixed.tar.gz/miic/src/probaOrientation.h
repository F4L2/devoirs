#ifndef _PROBAORIENTATION_H_
#define _PROBAORIENTATION_H_

int OrientTpl_LV_Deg_Propag(int NbTpl, int *Tpl, double *I3, double *ProbArrowhead, int LV, int deg, int Propag, int);

#endif
