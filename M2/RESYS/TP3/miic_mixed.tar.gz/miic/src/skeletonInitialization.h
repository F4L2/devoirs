#include "structure.h"

bool skeletonInitialization(Environment&);
