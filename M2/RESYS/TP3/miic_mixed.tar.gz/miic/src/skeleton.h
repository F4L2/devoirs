#include "structure.h"

bool skeleton(Environment&, std::string, double, int, char*[]);
