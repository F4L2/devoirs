#include "structure.h"


std::vector< std::vector <std::string> > confidenceCut(Environment&);